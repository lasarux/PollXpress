<?php

date_default_timezone_set('Europe/Amsterdam');
echo json_encode(date("F j, Y, g:i a"));